from selenium import webdriver
import time
import unittest
import sys
from pages.PageHome import HomePage
from common.CommonMethods import commonMethods
from selenium.webdriver.common.action_chains import ActionChains
#   import HtmlTestRunner
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))


class Login(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(executable_path=r'C:\Users\Ammulu\Documents\Selenium drivers\chromedriver.exe')
        cls.driver.implicitly_wait(30)
        cls.actions = ActionChains(cls.driver)
        cls.driver.maximize_window()

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")

    def test_loginTest(self):
        driver = self.driver
        actions = self.actions

        cm = commonMethods(driver, actions)
        cm.login()
        cm.navigatetoAddEmployee()
        cm.navigatetoJobtitle()

        time.sleep(2)

        homepage = HomePage(driver)
        homepage.clkwelcome()
        homepage.clklogout()

        time.sleep(5)


if __name__ == "__main__":
    unittest.main()
    #   unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='Reports'))
